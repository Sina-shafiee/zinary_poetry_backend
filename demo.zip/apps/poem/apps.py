from django.apps import AppConfig


class PoemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.poem'
